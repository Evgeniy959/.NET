using System;

namespace User
{
    public class UserClass
    {
        public string User { get; set; }
    }
}