﻿namespace EditorLib
{
    public class JpegDocument : Document
    {
        public JpegDocument() : base() { }
        public JpegDocument(string path, string content) : base(path, content) { }
    }
}