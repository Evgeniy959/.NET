﻿namespace EditorLib
{
    public class TxtDocument : Document
    {
        public TxtDocument() : base() { }
        public TxtDocument(string path, string content) : base(path, content) { }
    }
}