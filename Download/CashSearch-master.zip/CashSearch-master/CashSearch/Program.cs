﻿using System;

namespace CashSearch
{
    class Program
    {
        static void Main()
        {
            
        }
    }
}
