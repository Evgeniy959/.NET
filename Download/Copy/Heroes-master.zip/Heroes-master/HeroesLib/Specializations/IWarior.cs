﻿namespace HeroesLib.Specializations
{
    public interface IWarior
    {
        public int Strength{ get; set; }
    }
}