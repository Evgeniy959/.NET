﻿db.students.insertOne({
    "FirstName": "Andrey",
    "LastName": "Starinin",
    "DateOfBirth": "1986.02.18",
    "Phones": ["+79042144491", "257-57-55"],
    "Email": "starininandrey@gmail.com",
    "IsStudy": true,
    "Faculty": "SoftDev"
});

db.students.insertOne({
    "FirstName": "And",
    "LastName": "Star",
    "DateOfBirth": "1986.02.18",
    "Phones": ["+79042144491", "257-57-55"],
    "Email": "starininandrey@gmail.com",
    "IsStudy": false,
    "Faculty": "SoftDev"
});

db.students.insertOne({
    "FirstName": "An",
    "LastName": "St",
    "DateOfBirth": "1986.02.18",
    "Phones": ["+79042144491", "257-57-55"],
    "Email": "starininandrey@gmail.com",
    "IsStudy": true,
    "Faculty": "Design"
});