﻿namespace DataBaseLib
{
    public delegate void Message(string message);
}