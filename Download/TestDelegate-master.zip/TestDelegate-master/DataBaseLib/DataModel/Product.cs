﻿namespace DataBaseLib
{
    public class Product
    {
        public uint Id { get; set; }
        public string Name { get; set; }
        public uint Price { get; set; }
    }
}